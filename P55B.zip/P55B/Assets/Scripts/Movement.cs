﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

	public Rigidbody rigidbody;
	public float counter;

	void Start() {
		rigidbody = gameObject.GetComponent<Rigidbody>();
		rigidbody.AddForce(new Vector3(-1000f,-100f,0f));

	}

	void Update () {
		Vector3 velocity = -transform.position;
		float distance = velocity.magnitude == 0f ? 0.01f: velocity.magnitude;

		// float force = (rigidbody.mass * 100) / Mathf.Pow(distance, 2);
		// rigidbody.AddForce(force * velocity);

		if (distance > 40) {
			float force = (rigidbody.mass * 500) / Mathf.Pow(distance, 2);
			rigidbody.AddForce(force * velocity);
		} else if (distance < 10) {
			float force = (rigidbody.mass * 1000) / Mathf.Pow(distance, 2);
			rigidbody.AddForce(force * velocity);
		} else if (distance < 20) {
			float force = (rigidbody.mass * distance) / Mathf.Pow(distance, 2);
			rigidbody.AddForce(force * velocity);
		} else {
			float force = (rigidbody.mass * 100) / Mathf.Pow(distance, 2);
			rigidbody.AddForce(force * velocity);
		}


	}

	public void Move(Vector3 velocity) {
		rigidbody.AddForce(100 * velocity);
	}
}
